# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import itertools
import operator
from odoo import tools
from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class SaleReport(models.Model):
	_inherit = "sale.order"
	_description = "Listagem Materia Prima"
	_auto = False

	id = fields.Integer('id', readonly=True)
	name = fields.Char('Order Reference', readonly=True)
	bom_line_ids = fields.One2many('mrp.bom.line', readonly=True)
	partner_id = fields.Many2one('res.partner', 'Partner', readonly=True)
	company_id = fields.Many2one('res.company', 'Company', readonly=True)
	user_id = fields.Many2one('res.users', 'Salesperson', readonly=True)
	order_line = fields.One2many('sale.order.line', 'order_id', copy=True)
	
	state = fields.Selection([
		('draft', 'Draft Quotation'),
		('sent', 'Quotation Sent'),
		('sale', 'Sales Order'),
		('done', 'Sales Done'),
		('cancel', 'Cancelled'),
		], string='Status', readonly=True)

	def sale_bom(self):
		boms = {}
		product_qty_sub = 0.0
		product_qty = 0.0
		bom_line_sub_qty = 0.0

		for prod in self.order_line:
			product_qty_sub = 0.0
			product_qty = 0.0
			mrp_bom_rec = self.env['mrp.bom'].search([('product_tmpl_id', '=', prod.product_id.id)])

			for rec in mrp_bom_rec:

				bom_line = self.env['mrp.bom.line'].search([('bom_id', '=', rec.id)])
				product_qty_sub = 0.0

				# Salva a quantidade especificada na lista de materiais
				bom_qty = rec.product_qty
				
				for line in bom_line:

					# Multiplica materias primas pela quantidade da lista
					bom_line_qty = line.product_qty * bom_qty

					# Agora vamos ver se para o ID achado tem sub_bom
					mrp_bom_rec_sub =  self.env['mrp.bom'].search([('product_tmpl_id', '=', line.product_id.id)])

					for rec_sub in mrp_bom_rec_sub:
						
						bom_line_sub = self.env['mrp.bom.line'].search([('bom_id', '=', rec_sub.id)])

						for line_sub in bom_line_sub:
								
							product_uom_sub = line_sub.product_id.product_tmpl_id.uom_id.name
							bom_line_sub_qty = (line_sub.product_qty * bom_line_qty) * prod.product_qty
							product_id_sub = line_sub.product_id.id
							product_name_sub = line_sub.product_id.name
							product_codigo_sub = line_sub.product_id.product_tmpl_id.default_code

							if product_id_sub in boms:
								product_qty_sub = boms[product_id_sub].items()[3][1]
								product_qty_sub += bom_line_sub_qty
								boms[product_id_sub].update({'product_qty' : product_qty_sub})
							else:
								product_qty_sub = bom_line_sub_qty
								boms[product_id_sub] = {'product_name' : product_name_sub, 'product_qty' : product_qty_sub, 'codigo' : product_codigo_sub, 'uom' : product_uom_sub}

					template = self.env['product.template'].search([('id', '=', line.product_id.product_tmpl_id.id)])

					if(line.product_id.product_tmpl_id.purchase_ok != False or line.product_id.product_tmpl_id.sale_ok != False):
						#_logger.warning('\n\n=========================================\n')
						product_uom_p = line.product_id.product_tmpl_id.uom_id.name
						product_id = line.product_id.id
						product_name = line.product_id.name
						codigo = line.product_id.product_tmpl_id.default_code
								
						if product_id in boms:
							boms[product_id].update({'product_qty' : product_qty})
						else:
							product_qty = float(line.product_qty * prod.product_uom_qty)
							boms[product_id] = {'product_name' : product_name, 'product_qty' : product_qty, 'codigo' : codigo, 'uom' : product_uom_p}

		return boms