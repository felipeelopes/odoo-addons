{
    'name': 'MRP SALE BOM LIST',
    'version': '10.0.0.0.1',
    'summary': """Adiciona uma opção para imprimir quantidade de matéria prima na ordem de venda.""",
    'description': """Adiciona uma opção para imprimir quantidade de matéria prima na ordem de venda ou orçamento.""",
    'author': 'Felipe Lopes',
    'company': 'Felipe Lopes',
    'website': 'felipe_lopes@outlook.com',
    'category': 'Venda, Produção',
    'depends': ['sale', 'mrp'],
    'data': [
        'reports/listagem_mp.xml',
        'reports/listagem_template.xml'
    ],
    'installable': True,
    'auto_install': False,
}